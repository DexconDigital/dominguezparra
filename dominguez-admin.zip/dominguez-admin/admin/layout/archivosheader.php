<link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">
<link rel="stylesheet" href=".././estilos_admin_master/style.css">
<link rel="stylesheet" href=".././estilos_admin_master/bootstrap.min.css">
<link rel="stylesheet" href=".././estilos_admin_master/fondo.css">
